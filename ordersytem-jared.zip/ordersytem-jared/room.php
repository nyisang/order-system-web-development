 <?php
 include 'connection.php';
 include 'theme/header.php';
 include 'theme/sidebar.php';
 ?>



<div id="team-section">
  <div class="container"> 
    <div class="section-title">
       <marquee behavior="alternate"><h3>OUR ROOMS</h3></marquee>
      <hr>
   
    </div>
    <div class="row">
         
 <div class="col-lg-12">
         <div class="row">
            <div class="col-md-4 col-sm-6">    
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                            <img src="theme/carousel/b10.jpg" alt="..." style="width:100%"> 
                        </span>
                    </div>
                 
                    <div class="panel-body">
                        <h4>Single Room</h4>
                        <p>price: 3000</p>
                        <p>max member:1</p>
                        <a href="newres.php" class="btn btn-primary">Order Now!</a>
                   
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                            
                         <img src="theme/carousel/images (16).jpg" alt="..." style="width:100%">
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>Double Room</h4>
                        <p>price: 4000</p>
                        <p>max member:2</p>
                        <a href="newres.php" class="btn btn-primary">Order Now!</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                             <img src="theme/carousel/customorder.jpg" alt="..." style="width:100%">
                                  </span>
                                    </div>
                    <div class="panel-body">
                        <h4>Queen Room</h4>
                        <p>price:6500</p>
                        <p>max member:4</p>
                        <a href="newres.php" class="btn btn-primary">Order Now!</a>
                         </div>
                    </div>
                    </div>
                           <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                            <img src="theme/carousel/ship1.jpg" alt="..." style="width:100%">
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>King Room</h4>
                        <p>price:7000</p>
                        <p>max member:5</p>
                        <a href="newres.php" class="btn btn-primary">Order Now!</a>
                    </div>
                </div>
                </div>
                <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                            <img src="theme/carousel/ooo.jpg" alt="..." style="width:100%">
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>Triple Room</h4>
                        <p>price: 5500</p>
                        <p>max member:3</p>
                        <a href="newres.php" class="btn btn-primary">Order Now!</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                            <img src="theme/carousel/suply.jpg" alt="..." style="width:100%">
                        </span>
                    </div>
                    <div class="panel-body">
                        <h4>double-double Room</h4>
                        <p>price: 6000</p>
                        <p>max member:6</p>
                        <a href="newres.php" class="btn btn-primary">Order Now!</a>
          </div>
      </div>
    </div>
</div>
</div>
</div>
<?php include 'theme/stickyfooter.php';?>s