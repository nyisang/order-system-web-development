<!-- carousel image slider -->

<!--- <div class="w3-container w3-green head">
  <div id="carousel-example-generic" class="carousel slide" data-ride="carousel"> -->
    
    <!-- Indicators -->
    <!-- Wrapper for slides -->
   <!-- <div class="carousel-inner">
      <div class="item active">
        <img src="theme/carousel/a.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3>Quality Smartphone</h3> In affordable price.
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/b.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3>Apple Product</h3> MAC Book, Headphone and all iphone accesories.
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/c.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3>Professional Design</h3> iphone. samsung. G-pixel. LG. BlackBerry Smartphone
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/d.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3>Gadgets</h3> well design gadgets in store now .
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/e.jpg" alt="..." style="width:100%" >
        <div class="carousel-caption">
          <h3>Smartwatch</h3> Gorgeous Black Design.
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/f.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3>Eligant Design</h3> HTC Products.
        </div>
      </div>
      <div class="item">
        <img src="theme/carousel/g.jpg" alt="..." style="width:100%">
        <div class="carousel-caption">
          <h3>Apple & etc..</h3> All Apple Accesories.
        </div>
      </div>
    </div>

    <!-- Controls -->
<!--    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
      <span class="fas fa-fw fa-chevron-left" style="padding: 250px 10px 10px 10px"></span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
      <span class="fas fa-fw fa-chevron-right" style="padding: 260px 10px 10px 10px"></span>
    </a>
  </div>
</div>

<!-- Fontawesome -->
<!-- <link href=css/font-awesome.min.css" rel="stylesheet">

<!-- Bootstrap -->
<!-- <link href="css/bootstrap.min.css" rel="stylesheet">
<script src="js/indexes.js"></script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!--
<script src="js/1jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<!--
<script src="js/bootstrap.min.js"></script> -->

